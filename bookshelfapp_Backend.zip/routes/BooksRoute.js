import express from 'express';
import {
    createBooks,
    getBooks,
    getBooksById,
    updateBooks,
    deleteBooks,
} from '../controllers/Books.js';
const router = express.Router();

router.get('/books', getBooks);
router.get('/books/:bookId', getBooksById);
router.post('/books', createBooks);
router.put('/books/:bookId', updateBooks);
router.delete('/books/:id', deleteBooks);

export default router;
