import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import db from '../config/Database.js';

import BooksRoute from '../routes/BooksRoute.js';
dotenv.config();

const app = express();

app.use(
    cors({
        credentials: true,
        origin: '*',
    })
);

app.use(express.json());
app.use(BooksRoute);

// db.sync();
app.listen(process.env.APP_PORT || 9000, () => {
    console.log(
        `Server up and running at port ${process.env.APP_PORT || 9000}...`
    );
});
