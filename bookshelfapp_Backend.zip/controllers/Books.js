import Books from '../models/BooksModel.js';
import { nanoid } from 'nanoid';

// create book
export const createBooks = async (req, res) => {
    const {
        name,
        year,
        author,
        summary,
        publisher,
        pageCount,
        readPage,
        reading,
    } = req.body;

    // error handle
    if (!name) {
        return res.status(400).json({
            status: 'fail',
            message: 'Gagal menambahkan buku, mohon isi nama buku',
        });
    }

    if (
        !year ||
        !author ||
        !summary ||
        !publisher ||
        !pageCount ||
        !readPage ||
        reading === undefined
    ) {
        return res.status(400).json({
            status: 'fail',
            message: 'Gagal menambahkan buku, mohon isi semua kolom',
        });
    }

    const finished = pageCount === readPage;
    const id = nanoid();

    if (readPage > pageCount)
        return res.status(400).json({
            status: 'fail',
            message:
                'Gagal menambahkan buku. readPage tidak boleh lebih besar dari pageCount',
        });

    try {
        await Books.create({
            id,
            name,
            year,
            author,
            summary,
            publisher,
            pageCount,
            readPage,
            reading,
            finished,
        });
        res.status(201).json({
            status: 'success',
            msg: 'Buku berhasil ditambahkan',
            data: {
                BookId: id,
            },
        });
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
};

export const getBooks = async (req, res) => {
    try {
        const { name } = req.query;
        let condition = {};

        if (name) {
            condition.name = {
                [Op.iLike]: `%${name}%`,
            };
        }

        const books = await Books.findAll({
            where: condition,
            attributes: ['id', 'author', 'publisher'],
        });

        res.status(200).json({
            status: 'success',
            data: {
                books,
            },
        });
    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
};
export const getBooksById = async (req, res) => {
    const bookid = req.params.bookId;
    try {
        const book = await Books.findOne({
            where: {
                id: bookid,
            },
        });
        if (!book)
            return res.status(404).json({
                status: 'fail',
                message: 'buku tidak ditemukan',
            });
        return res.status(200).json({
            status: 'success',
            data: {
                book,
            },
        });
    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
};

export const updateBooks = async (req, res) => {
    const booksId = req.params.bookId;

    const updateBook = await Books.findOne({
        where: {
            id: booksId,
        },
    });
    if (!updateBook)
        return res.status(404).json({
            status: 'fail',
            message: 'Gagal memperbarui buku. Id tidak ditemukan',
        });

    const {
        name,
        year,
        author,
        summary,
        publisher,
        pageCount,
        readPage,
        reading,
    } = req.body;

    if (!name) {
        return res.status(400).json({
            status: 'fail',
            message: 'Gagal memperbarui buku, mohon isi nama buku',
        });
    }

    if (
        !year ||
        !author ||
        !summary ||
        !publisher ||
        !pageCount ||
        !readPage ||
        reading === undefined
    ) {
        return res.status(400).json({
            status: 'fail',
            message: 'Gagal memperbarui buku, mohon isi semua kolom',
        });
    }

    const finished = pageCount === readPage;

    if (readPage > pageCount)
        return res.status(400).json({
            status: 'fail',
            message:
                'Gagal menambahkan buku. readPage tidak boleh lebih besar dari pageCount',
        });

    try {
        await Books.update(
            {
                name,
                year,
                author,
                summary,
                publisher,
                pageCount,
                readPage,
                reading,
                finished,
            },
            {
                where: {
                    id: booksId,
                },
            }
        );
        return res.status(200).json({
            status: 'success',
            message: 'Buku berhasil diperbarui',
        });
    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
};

export const deleteBooks = async (req, res) => {
    try {
        const product = await Product.findOne({
            where: {
                uuid: req.params.id,
            },
        });
        if (!product)
            return res.status(404).json({ msg: 'Data tidak ditemukan' });
        const { name, price } = req.body;
        if (req.role === 'admin') {
            await Product.destroy({
                where: {
                    id: product.id,
                },
            });
        } else {
            if (req.userId !== product.userId)
                return res.status(403).json({ msg: 'Akses terlarang' });
            await Product.destroy({
                where: {
                    [Op.and]: [{ id: product.id }, { userId: req.userId }],
                },
            });
        }
        res.status(200).json({ msg: 'Product deleted successfuly' });
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
};
